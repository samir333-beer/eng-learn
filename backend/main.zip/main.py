import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import google.generativeai as genai

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

GOOGLE_API_KEY = ""
genai.configure(api_key=GOOGLE_API_KEY)
model = genai.GenerativeModel('gemini-1.5-flash')

@app.get("/")
async def read_root(topic: str = "travel"):
    try:
        prompt = f"Напиши 1 полозьзователю фразу на англиском и ее перевод на русскую тему: {topic}. Только текст фразы."
        response = model.generate_content(prompt)
        phrase = response.text.strip()
        return {"message": phrase}
    except Exception as e:
        print(f"Ошибка: {e}")



