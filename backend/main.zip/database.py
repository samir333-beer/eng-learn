englich_phrases = [
    "Consistency is the key to success",
    "Belive in yourself and you will be unstoppable",
    "Don't stop until you are proud",
    "Learning a language is a big adventure",
    "Practice makes perfect",
]